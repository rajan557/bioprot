-- Remove the public SELECT policy that exposes sensitive customer data
DROP POLICY IF EXISTS "Sample requests are readable by everyone" ON public.sample_requests;

-- Create a restricted policy that only allows authenticated admin users to view sample requests
-- This protects customer contact information from competitors and unauthorized access
CREATE POLICY "Only authenticated admins can view sample requests" 
ON public.sample_requests 
FOR SELECT 
TO authenticated
USING (false); -- For now, block all reads until proper admin role system is implemented

-- Keep the INSERT policy for anonymous users to submit sample requests
-- This maintains the functionality for customers to submit requests without registration