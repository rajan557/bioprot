-- Create a table for sample requests
CREATE TABLE public.sample_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  company TEXT NOT NULL,
  hear_about TEXT NOT NULL,
  request_type TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  synced_to_google_sheets BOOLEAN DEFAULT false
);

-- Enable Row Level Security
ALTER TABLE public.sample_requests ENABLE ROW LEVEL SECURITY;

-- Create policy for anyone to insert (since this is a public form)
CREATE POLICY "Anyone can submit sample requests" 
ON public.sample_requests 
FOR INSERT 
WITH CHECK (true);

-- Create policy for reading (only admins or specific use cases)
CREATE POLICY "Sample requests are readable by everyone" 
ON public.sample_requests 
FOR SELECT 
USING (true);