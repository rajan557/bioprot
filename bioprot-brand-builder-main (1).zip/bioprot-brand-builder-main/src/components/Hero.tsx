import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";
import bioprotLogo from "@/assets/bioprot-logo-final.png";
import heroBackground from "/lovable-uploads/5d8caa60-f65c-4b6f-86aa-81d1304a5b54.png";
export const Hero = () => {
  const handleCallNow = () => {
    window.open("tel:+919555307292", "_self");
  };
  const handleRequestSample = () => {
    window.location.href = '/sample-request';
  };
  return <div className="relative min-h-screen flex items-center justify-center overflow-hidden pt-8 w-full">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img src={heroBackground} alt="New Hero Background" className="w-full h-full object-cover" key="new-background" />
        <div className="absolute inset-0 bg-background/60"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center w-full max-w-full">
        <div className="max-w-4xl mx-auto">
          {/* Logo with closer spacing to sub-heading */}
          <div className="-mb-20">
            <div className="inline-block">
              <img src={bioprotLogo} alt="BioProt Logo" className="h-96 md:h-[28rem] lg:h-[34rem] mx-auto" />
            </div>
          </div>
          
          {/* Sub-heading positioned closer to logo */}
          <div className="text-center">
            <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold font-brand mb-6 text-primary">
              Next Generation Yeast Protein for Performance Nutrition<br />
              <span className="text-lg md:text-2xl lg:text-3xl font-normal mt-3 block">The Future of Proteins is Gut Friendly, Sustainable and Better than Whey</span>
            </h2>
            </div>
            
            {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
            <Button onClick={handleRequestSample} size="lg" className="text-lg px-8 py-6 bg-primary hover:bg-primary/90 text-primary-foreground min-h-[56px]">
              Request Sample
            </Button>
            
          </div>
          
          {/* Free Samples Note */}
          <p className="text-sm text-muted-foreground mt-6">
            Free samples shipped worldwide within 24 hours
          </p>
        </div>
      </div>
      
      {/* Decorative Elements - Centered */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-primary/10 rounded-full blur-3xl"></div>
      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-48 h-48 bg-secondary/10 rounded-full blur-3xl"></div>
    </div>;
};