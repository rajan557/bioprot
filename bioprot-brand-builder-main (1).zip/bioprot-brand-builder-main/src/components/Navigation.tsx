import React from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import bioprotLogo from "@/assets/bioprot-logo-high-res.png";

export const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const handleWhatsApp = () => {
    window.open("https://wa.me/917007277112?text=Hi%2C%20I%20have%20some%20queries%20regarding%20BioProt", "_blank");
  };

  const handleLogoClick = () => {
    if (location.pathname === '/') {
      // If on home page, just scroll to top
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    } else {
      // If on any other page, navigate to home page
      navigate('/');
    }
  };
  return <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button onClick={handleLogoClick} className="flex items-center space-x-2">
            <img src={bioprotLogo} alt="BioProt Logo" className="h-16 w-auto" />
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/blogs" 
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Blogs
            </Link>
            {/* WhatsApp Icon */}
            <button onClick={handleWhatsApp} className="ml-4">
              <img 
                src="/lovable-uploads/c66f74a4-b577-4b1c-9f1e-eb49afd43ea7.png" 
                alt="WhatsApp" 
                className="h-10 w-10 hover:scale-110 transition-transform duration-200"
              />
            </button>
          </div>

          {/* Mobile Navigation */}
          <div className="flex items-center space-x-4 md:hidden">
            <Link 
              to="/blogs" 
              className="text-foreground hover:text-primary transition-colors font-medium text-sm"
            >
              Blogs
            </Link>
            {/* WhatsApp Icon for Mobile */}
            <button onClick={handleWhatsApp}>
              <img 
                src="/lovable-uploads/c66f74a4-b577-4b1c-9f1e-eb49afd43ea7.png" 
                alt="WhatsApp" 
                className="h-8 w-8 hover:scale-110 transition-transform duration-200"
              />
            </button>
          </div>
        </div>
      </div>
    </nav>;
};