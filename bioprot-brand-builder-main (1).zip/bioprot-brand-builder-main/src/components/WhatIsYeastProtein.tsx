import { Card, CardContent } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Microscope, Leaf, Shield, Zap } from "lucide-react";
const benefits = [{
  icon: Microscope,
  title: "Scientifically Proven",
  description: "Advanced fermentation technology creates a complete protein with all essential amino acids"
}, {
  icon: Leaf,
  title: "Natural & Pure",
  description: "Derived from sustainable yeast sources without artificial additives or harmful chemicals"
}, {
  icon: Zap,
  title: "Enhanced Performance",
  description: "Optimized bioavailability ensures maximum absorption and utilization by your body"
}];
export const WhatIsYeastProtein = () => {
  return <section className="py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-brand mb-6 text-foreground">
            What is <span className="text-primary">Yeast Protein</span>?
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-brand-accent-3 mx-auto mb-8"></div>
          
          <div className="max-w-4xl mx-auto">
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8">Yeast protein is a revolutionary protein source derived from specially cultivated yeasts through advanced fermentation technology. Unlike traditional animal-based proteins, yeast protein offers a complete amino acid profile while being completely vegan and sustainable.</p>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              Our proprietary process creates a protein that not only matches but exceeds the quality of 
              traditional whey proteins, while being gentler on your digestive system and the environment.
            </p>
          </div>
        </div>

        {/* Unified Carousel for all screen sizes */}
        <div className="max-w-5xl mx-auto">
          <Carousel className="w-full">
            <CarouselContent className="-ml-2 md:-ml-6">
              {benefits.map((benefit, index) => (
                <CarouselItem key={index} className="pl-2 md:pl-6 basis-full md:basis-1/2 lg:basis-1/3">
                  <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-card/80 backdrop-blur-sm group h-full">
                    <CardContent className="p-8 text-center">
                      <div className="mb-6">
                        <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary to-brand-accent-2 rounded-full flex items-center justify-center shadow-brand group-hover:shadow-glow transition-all duration-300">
                          <benefit.icon className="w-8 h-8 text-primary-foreground" />
                        </div>
                      </div>
                      <h3 className="text-xl font-bold font-brand mb-4 text-card-foreground">
                        {benefit.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {benefit.description}
                      </p>
                    </CardContent>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
            {/* Arrows only visible on mobile */}
            <CarouselPrevious className="md:hidden" />
            <CarouselNext className="md:hidden" />
          </Carousel>
        </div>
      </div>
    </section>;
};