import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Users, Globe, Lightbulb } from "lucide-react";

const highlights = [
  {
    icon: Award,
    title: "Award Winning",
    description: "Recognized ingredient technology company"
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Engineers and scientists from world's best institutions"
  },
  {
    icon: Globe,
    title: "Global Reach",
    description: "Shipping worldwide within 24 hours"
  },
  {
    icon: Lightbulb,
    title: "Innovation Focus",
    description: "Next generation ingredients and systems"
  }
];

const institutions = [
  "Imperial College London",
  "Indian Institutes of Technology", 
  "London Business School",
  "University of Helsinki",
  "CFTRI",
  "NIFTEM",
  "University of Cambridge"
];

export const AboutArboreal = () => {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-brand mb-6 text-foreground">
            About <span className="text-primary">Arboreal</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-brand-accent-3 mx-auto"></div>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Company Description */}
          <Card className="mb-12 shadow-xl border-0 bg-card/80 backdrop-blur-sm">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl md:text-3xl font-bold font-brand text-foreground">
                Pioneering the Future of Nutrition
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg text-muted-foreground leading-relaxed text-center max-w-4xl mx-auto mb-8">
                Arboreal is an award winning ingredient technology company focused on designing, developing and 
                delivering the next generation of innovative ingredients and ingredient systems for the 
                nutraceutical and food industries.
              </p>
              
              <p className="text-lg text-muted-foreground leading-relaxed text-center max-w-4xl mx-auto mb-8">
                We are a bunch of passionate engineers and scientists from some of the world's best institutions 
                working together to revolutionize how we think about nutrition and sustainability.
              </p>

              {/* Team Image */}
              <div className="mt-12">
                <img 
                  src="/lovable-uploads/01650ec3-b446-4d4b-a378-920d53def928.png" 
                  alt="The Arboreal team celebrating together"
                  className="w-full max-w-4xl mx-auto rounded-lg shadow-lg"
                />
                <p className="text-center text-sm text-muted-foreground mt-4 font-medium">
                  Our passionate team of engineers and scientists
                </p>
              </div>
            </CardContent>
          </Card>


        </div>
      </div>
    </section>
  );
};