import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useCallback } from "react";

const recipes = [
  {
    emoji: "🥤",
    title: "Vegan Protein Smoothie",
    description: "Blend BioProt with plant milk, banana & berries for a high-protein, lactose-free drink."
  },
  {
    emoji: "🍪",
    title: "No-Bake Energy Bites",
    description: "Mix BioProt with oats, nut butter & dates for a nutritious snack."
  },
  {
    emoji: "🫓",
    title: "High-Protein Flatbreads",
    description: "Enrich chapatis or wraps with BioProt for added nutrition."
  },
  {
    emoji: "🍫",
    title: "Fudgy Vegan Brownies",
    description: "Bake delicious protein-rich brownies with BioProt."
  },
  {
    emoji: "🍔",
    title: "Protein-Rich Veggie Patties",
    description: "Combine BioProt with mashed vegetables, spices, and a binder like chickpea flour. Shape into patties and pan-fry for a nutritious snack or burger filling."
  },
  {
    emoji: "🍦",
    title: "Protein Banana Ice Cream",
    description: "Blend frozen bananas with BioProt, a splash of plant milk, and a dash of vanilla for a creamy, high-protein dessert—no added sugar needed!"
  }
];

import superyouLogo from "@/assets/brands/superyou.jpg";
import yogabarLogo from "@/assets/brands/yogabar.png";
import fueloneLogo from "@/assets/brands/fuelone.jpg";
import cosmixLogo from "@/assets/brands/cosmix.jpg";

const brands = [
  { name: "SuperYou", logo: superyouLogo },
  { name: "Yogabar", logo: yogabarLogo },
  { name: "Fuel One", logo: fueloneLogo },
  { name: "Cosmix Wellness", logo: cosmixLogo },
  { name: "Beast Life", logo: "/lovable-uploads/014ba588-7ea6-405d-a12c-c2a7f91f8d10.png" }
];

export const HowToUse = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel({ 
    align: 'center', 
    skipSnaps: false,
    dragFree: false,
    loop: true
  });

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  return (
    <section className="py-12 md:py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-brand mb-6 text-foreground">
            Recipes You Can Make with <span className="text-primary">BioProt</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Discover delicious ways to incorporate BioProt into your daily meals and snacks.
          </p>
        </div>

        {/* Recipes Carousel */}
        <div className="relative mb-12 md:mb-16 max-w-2xl mx-auto">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex">
              {recipes.map((recipe, index) => (
                <Card key={index} className="flex-none w-full min-w-0 mx-3 border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white">
                  <CardContent className="p-6 md:p-8">
                    <div className="flex items-center gap-6">
                      {/* Left side - Text content */}
                      <div className="flex-1 text-left">
                        <h3 className="text-xl md:text-2xl font-bold font-brand mb-3 text-foreground">
                          {recipe.title}
                        </h3>
                        <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
                          {recipe.description}
                        </p>
                      </div>
                      
                      {/* Right side - Icon */}
                      <div className="flex-shrink-0">
                        <div className="w-20 h-20 md:w-24 md:h-24 bg-gradient-to-br from-amber-100 to-green-100 rounded-2xl flex items-center justify-center text-4xl md:text-5xl shadow-md">
                          {recipe.emoji}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Navigation Arrows */}
          <Button
            variant="outline"
            size="icon"
            className="absolute left-4 top-3/4 -translate-y-1/2 z-10 bg-transparent hover:bg-white/20 border-transparent shadow-lg"
            onClick={scrollPrev}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            className="absolute right-4 top-3/4 -translate-y-1/2 z-10 bg-transparent hover:bg-white/20 border-transparent shadow-lg"
            onClick={scrollNext}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Brands Section */}
        <div className="text-center">
          <h3 className="text-2xl md:text-3xl font-bold font-brand mb-8 text-foreground">
            Don't just take our word for it!
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Here are some of the leading Brands already using Yeast Protein:
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 md:gap-6">
            {brands.map((brand, index) => (
              <div 
                key={index}
                className="flex items-center justify-center bg-white rounded-lg p-4 md:p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 min-w-[120px]"
              >
                <img 
                  src={brand.logo} 
                  alt={`${brand.name} logo`}
                  className="h-10 md:h-12 object-contain"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};