import { Settings, Zap, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
const features = [{
  icon: Settings,
  title: "Superior Functional Performance",
  description: "Enhanced solubility, smooth texture, and excellent mixing properties – with no grit or off-flavors."
}, {
  icon: Zap,
  title: "Advanced Nutritional Profile",
  description: "Rich in essential amino acids, gut-friendly, and naturally low in allergens and anti-nutrients."
}, {
  icon: TrendingUp,
  title: "Cost & Scale Advantage",
  description: "Delivers better economics than whey and competes with leading vegan proteins, thanks to scalable tech."
}];
export const TerraFermTechnology = () => {
  return <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">The TerraFerm™ Technology </h2>
          <p className="text-lg text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            At the core of BioProt's breakthrough functionality is our proprietary TerraFerm™ Technology – a next-gen precision fermentation platform that delivers exceptional protein quality, performance, and scalability.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300 bg-card border-border shadow-sm">
              <CardContent className="p-8">
                <div className="mb-6 flex justify-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <feature.icon className="w-8 h-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-foreground">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>)}
        </div>
      </div>
    </section>;
};