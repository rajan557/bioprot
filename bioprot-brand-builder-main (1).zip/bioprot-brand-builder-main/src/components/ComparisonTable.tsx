import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";

const comparisonData = [
  {
    feature: "Complete Amino Profile (PDCAAS = 1)",
    bioprot: true,
    wpc80: true,
    wpi90: true,
    pea: false,
    soy: true,
    other: true
  },
  {
    feature: "Lactose Free",
    bioprot: true,
    wpc80: false,
    wpi90: true,
    pea: true,
    soy: true,
    other: true
  },
  {
    feature: "Vegan",
    bioprot: true,
    wpc80: false,
    wpi90: false,
    pea: true,
    soy: true,
    other: true
  },
  {
    feature: "Superior Solubility",
    bioprot: true,
    wpc80: false,
    wpi90: true,
    pea: false,
    soy: false,
    other: false
  },
  {
    feature: "Neutral Taste",
    bioprot: true,
    wpc80: true,
    wpi90: true,
    pea: false,
    soy: false,
    other: false
  },
  {
    feature: "Heat Stable",
    bioprot: true,
    wpc80: false,
    wpi90: false,
    pea: true,
    soy: true,
    other: true
  },
  {
    feature: "Prebiotic Benefits",
    bioprot: true,
    wpc80: false,
    wpi90: false,
    pea: false,
    soy: false,
    other: true
  },
  {
    feature: "Low Environmental Impact",
    bioprot: true,
    wpc80: false,
    wpi90: false,
    pea: true,
    soy: true,
    other: true
  },
  {
    feature: "Allergen Free",
    bioprot: true,
    wpc80: false,
    wpi90: false,
    pea: true,
    soy: false,
    other: true
  },
  {
    feature: "Smooth Texture",
    bioprot: true,
    wpc80: true,
    wpi90: true,
    pea: false,
    soy: false,
    other: false
  },
  {
    feature: "Cost Effective",
    bioprot: true,
    wpc80: false,
    wpi90: false,
    pea: true,
    soy: true,
    other: true
  },
  {
    feature: "Gut Friendly",
    bioprot: true,
    wpc80: false,
    wpi90: true,
    pea: true,
    soy: false,
    other: true
  }
];

const columns = [
  { key: 'bioprot', title: 'BioProt Yeast Protein', highlight: true },
  { key: 'wpc80', title: 'Whey Protein Concentrate' },
  { key: 'wpi90', title: 'Whey Protein Isolate' },
  { key: 'pea', title: 'Pea Protein Isolate' },
  { key: 'soy', title: 'Isolated Soy Protein' },
  { key: 'other', title: 'Other Yeast Proteins' }
];

export const ComparisonTable = () => {
  return (
    <section className="py-12 md:py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-brand mb-6 text-foreground">
            <span className="text-primary">BioProt</span> vs The Competition
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            See how BioProt Yeast Protein compares to traditional whey proteins and other alternatives
          </p>
        </div>

        <Card className="overflow-hidden shadow-xl">
          <CardHeader className="bg-gradient-to-r from-primary to-brand-accent-2 text-primary-foreground">
            <CardTitle className="text-2xl font-brand text-center">
              Protein Comparison Matrix
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm md:text-base">
                <thead>
                  <tr className="bg-muted/50">
                    <th className="text-left p-3 md:p-4 font-brand font-semibold">Features</th>
                    {columns.map((col) => (
                      <th 
                        key={col.key} 
                        className={`text-center p-3 md:p-4 font-brand font-semibold ${
                          col.highlight ? 'bg-primary/10 text-primary' : ''
                        }`}
                      >
                        {col.title}
                        {col.highlight && (
                          <Badge className="ml-2 bg-primary text-primary-foreground">
                            Our Product
                          </Badge>
                        )}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonData.map((row, index) => (
                    <tr 
                      key={index} 
                      className={`border-b hover:bg-muted/30 transition-colors ${
                        index % 2 === 0 ? 'bg-background' : 'bg-muted/10'
                      }`}
                    >
                      <td className="p-3 md:p-4 font-medium text-foreground">
                        {row.feature}
                      </td>
                      {columns.map((col) => (
                        <td 
                          key={col.key} 
                          className={`text-center p-3 md:p-4 ${
                            col.highlight ? 'bg-primary/5' : ''
                          }`}
                        >
                          {row[col.key as keyof typeof row] === true ? (
                            <Check className={`w-6 h-6 mx-auto ${
                              col.highlight ? 'text-primary' : 'text-green-600'
                            }`} />
                          ) : (
                            <X className="w-6 h-6 text-red-500 mx-auto" />
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};
