import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

const contactInfo = [
  {
    icon: MapPin,
    title: "Our Location",
    content: "Arboreal Bio Innovations, Biotech Park, Kursi Rd, Sector G, Jankipuram, Lucknow, Uttar Pradesh 226021"
  },
  {
    icon: Phone,
    title: "Phone",
    content: "+91 95553 07292"
  },
  {
    icon: Mail,
    title: "Email",
    content: "SALES@ARBOREALBIO.COM"
  },
  {
    icon: Clock,
    title: "Sample Delivery",
    content: "Free samples shipped anywhere in the world within 24 hours"
  }
];

export const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-brand mb-6 text-foreground">
            For more <span className="text-primary">information</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Ready to revolutionize your protein products? Contact us today for free samples and expert consultation.
          </p>
          <div className="w-24 h-1 bg-primary mx-auto mt-6"></div>
        </div>

        <div className="max-w-6xl mx-auto">

          {/* CTA Section */}
          <div className="text-center mt-12">
            <div className="flex flex-col sm:flex-row gap-4 justify-center px-4 md:px-0">
              <Button 
                size="lg" 
                onClick={() => window.location.href = '/sample-request'}
                className="text-lg px-8 py-6 bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg min-h-[56px] touch-manipulation"
              >
                <Mail className="w-5 h-5 mr-2" />
                Get Samples
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => window.open("tel:+917007277112", "_self")}
                className="text-lg px-8 py-6 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground min-h-[56px] touch-manipulation"
              >
                <Phone className="w-5 h-5 mr-2" />
                Call Us Now
              </Button>
            </div>
            
            <p className="text-sm text-muted-foreground mt-6">
              ✓ No commitment required  ✓ Worldwide shipping  ✓ 24-hour delivery
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};