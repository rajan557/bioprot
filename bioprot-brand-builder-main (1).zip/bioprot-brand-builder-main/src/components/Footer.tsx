import { Mail, Phone, MapPin } from "lucide-react";
export const Footer = () => {
  return <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Brand Section */}
          <div className="text-center md:text-left">
            <h1 className="text-3xl md:text-4xl font-bold font-brand mb-4 text-background">BIOPROT</h1>
            <h2 className="text-xl md:text-2xl font-bold font-brand mb-2 text-background/90">
              Reinventing Proteins for Performance Nutrition
            </h2>
            <p className="text-background/70 text-sm md:text-base leading-relaxed">
              The future of proteins is - gut friendly, sustainable and better than whey
            </p>
          </div>

          {/* Contact Info */}
          <div className="text-center md:text-right">
            <h3 className="text-xl font-bold font-brand mb-4 text-background">
              Contact Information
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-center md:justify-end text-background/80">
                <Phone className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="text-sm">+917007277112 </span>
              </div>
              <div className="flex items-center justify-center md:justify-end text-background/80">
                <Mail className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="text-sm">manish@arborealbio.com</span>
              </div>
              <div className="flex items-start justify-center md:justify-end text-background/80">
                <MapPin className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-center md:text-right">
                  <strong>Arboreal Bioinnovations Private Limited</strong><br />
                  Biotech Park, Sector G, Jankipuram<br />
                  Lucknow 226021, India
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-background/20 mt-8 pt-8 text-center">
          <p className="text-background/60 text-sm">© 2025 Arboreal BioInnovations. All rights reserved.</p>
        </div>
      </div>
    </footer>;
};