import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { blogPosts } from "@/data/blogPosts";

const Blogs = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background font-brand">
      <Navigation />
      <div className="pt-16">
        {/* Hero Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              BioProt Blogs
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Stay updated with the latest insights on yeast protein, nutrition science, and sustainable food innovation.
            </p>
          </div>
        </section>

        {/* Blog Posts Grid */}
        <section className="pb-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid gap-8 md:grid-cols-2">
              {blogPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="relative h-48 md:h-56">
                    <img 
                      src={post.image} 
                      alt={`${post.title} - Bioprot yeast protein blog`} 
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="mb-3">
                      <p className="text-sm text-muted-foreground">
                        {new Date(post.date).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </p>
                    </div>
                    <h2 className="text-xl md:text-2xl font-bold text-foreground mb-3 line-clamp-2">
                      {post.title}
                    </h2>
                    <p className="text-muted-foreground mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <Button 
                      onClick={() => navigate(`/blog/${post.id}`)}
                      className="w-full"
                    >
                      Read More
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Blogs;