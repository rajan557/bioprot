import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { WhyChooseBioprot } from "@/components/WhyChooseBioprot";
import { WhatIsYeastProtein } from "@/components/WhatIsYeastProtein";
import { ComparisonTable } from "@/components/ComparisonTable";
import { TerraFermTechnology } from "@/components/TerraFermTechnology";
import { HowToUse } from "@/components/HowToUse";
import { AboutArboreal } from "@/components/AboutArboreal";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background font-brand w-full overflow-x-hidden">
      <Navigation />
      <div id="hero">
        <Hero />
      </div>
      <div id="why-bioprot">
        <WhyChooseBioprot />
      </div>
      <div id="yeast-protein">
        <WhatIsYeastProtein />
      </div>
      <ComparisonTable />
      <TerraFermTechnology />
      <HowToUse />
      <AboutArboreal />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;