import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";

const HowToUse = () => {
  return (
    <div className="min-h-screen bg-background font-brand">
      <Navigation />
      <div className="pt-16 flex-1 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-foreground mb-4">How to Use</h1>
          <p className="text-muted-foreground">This content has been moved to the main page.</p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default HowToUse;